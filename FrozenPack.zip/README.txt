FROZEN SWORD (netherite) - resource pack

Two ways to get the Frozen Sword. Both use a netherite sword.

A) item_model (recommended, 1.21.4+):
   /give @p netherite_sword[item_model="minecraft:frozen_sword"]

B) custom_model_data (if your plugin only supports this):
   /give @p netherite_sword[custom_model_data={floats:[1001.0]}]
   (use 1001 as the custom model data value)

Normal netherite swords stay unchanged.

Server install: upload FrozenPack.zip somewhere with a direct download link,
then set resource-pack=<link> and resource-pack-sha1=<sha1> in server.properties.
Single player: put FrozenPack.zip in .minecraft/resourcepacks and enable it.

FrozenShards /shardshop: give the item with command A or B in the shop entry.

SHOP ICON TRICK: the knowledge_book item is re-skinned as the Frozen Sword.
In shardshop.yml set "material: KNOWLEDGE_BOOK" for the Frozen Sword entry so the
menu icon shows the katana. The give command still gives a netherite sword.

DEATH MACE: dark Viking hammer. Give it with:
/minecraft:give @p mace[item_model="minecraft:death_mace",custom_name={text:"Death Mace",color:"dark_purple",bold:true,italic:false},enchantments={"minecraft:wind_burst":1,"minecraft:density":5,"minecraft:breach":4}]
Needs the FrozenFreeze plugin (1.2.0) for the teleport and blindness abilities.
